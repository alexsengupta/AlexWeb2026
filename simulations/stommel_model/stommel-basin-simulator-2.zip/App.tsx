
import React, { useState } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { OceanSimulation } from './components/OceanSimulation';
import { HelpModal, InfoModal } from './components/Modals';
import { SimulationParams } from './types';

const App: React.FC = () => {
  const [params, setParams] = useState<SimulationParams>({
    beta: 2e-11, // Typical mid-latitude beta
    f0: 1e-4,    // Typical mid-latitude Coriolis
    drag: 2e-5,  
    windStress: 0.2, 
    viscosity: 400000, 
    windProfile: 'SINGLE_GYRE',
    isRunning: true,
    showVectors: true,
    gridResolution: 60 // 60x60 grid
  });

  const [simKey, setSimKey] = useState(0);
  const [showHelp, setShowHelp] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  const handleReset = () => {
    // Force re-mount of simulation to reset state
    setSimKey(prev => prev + 1);
    setParams(prev => ({ ...prev, isRunning: true }));
  };

  return (
    <div className="h-screen w-screen bg-slate-950 flex flex-col overflow-hidden">
      <HelpModal isOpen={showHelp} onClose={() => setShowHelp(false)} />
      <InfoModal isOpen={showInfo} onClose={() => setShowInfo(false)} />

      {/* Header */}
      <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-6 z-10 shrink-0">
        <div className="flex items-center gap-3">
           <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg shadow-lg flex items-center justify-center">
             <span className="text-white font-bold">St</span>
           </div>
           <h1 className="text-xl font-bold text-slate-100 tracking-tight">Stommel Basin Simulator</h1>
        </div>
        <div className="flex items-center gap-3">
            <div className="text-slate-400 text-xs hidden md:block mr-4">
            Pedagogical Ocean Model • React + Canvas
            </div>
            <button 
                onClick={() => setShowHelp(true)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium rounded border border-slate-700 transition-colors"
            >
                Help
            </button>
            <button 
                onClick={() => setShowInfo(true)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium rounded border border-slate-700 transition-colors"
            >
                Info
            </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex min-h-0">
        
        {/* Left: Simulation & Visualization */}
        <div className="flex-1 flex flex-col relative p-4 gap-4">
          
          <div className="flex-1 min-h-0 relative">
             <OceanSimulation key={simKey} params={params} />
             
             {/* Overlay Legend - Moved to Top Right to avoid axis collision */}
             <div className="absolute top-4 right-4 bg-slate-900/80 backdrop-blur border border-slate-700 p-3 rounded-lg text-xs text-white z-10 shadow-xl">
                <div className="font-semibold mb-2 text-slate-200">Sea Surface Height (η)</div>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-3 rounded bg-gradient-to-r from-[rgb(10,25,70)] via-[rgb(240,240,245)] to-[rgb(100,20,20)]"></div>
                </div>
                <div className="flex justify-between mt-1 text-slate-400 text-[10px]">
                   <span>Low</span>
                   <span>High</span>
                </div>
                <div className="mt-2 pt-2 border-t border-slate-600">
                  <div className="flex items-center gap-2">
                     <div className="w-3 h-3 bg-lime-400 rounded-full"></div>
                     <span className="text-slate-200">Particles (Click to add)</span>
                  </div>
                </div>
             </div>
          </div>
        </div>

        {/* Right: Controls */}
        <div className="w-96 flex flex-col gap-0 border-l border-slate-800 bg-slate-900 shrink-0 p-4 overflow-y-auto">
             <ControlPanel params={params} setParams={setParams} onReset={handleReset} />
        </div>
      </main>
    </div>
  );
};

export default App;
