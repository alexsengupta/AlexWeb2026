import React, { useState, useRef, useEffect } from 'react';
import { askOceanographer } from '../services/geminiService';
import { ChatMessage, SimulationParams } from '../types';

interface AssistantProps {
  params: SimulationParams;
}

export const Assistant: React.FC<AssistantProps> = ({ params }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hi! I'm your AI Oceanographer. Ask me about the simulation, like 'Why is the current faster on the left?' or 'What does beta do?'" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const context = `
      Coriolis f0: ${params.f0}
      Beta: ${params.beta}
      Wind Stress: ${params.windStress}
      Friction: ${params.drag}
      Viscosity: ${params.viscosity}
      Basin: Pacific Scale (12000km x 8000km)
      Grid Resolution: 200km
      State: ${params.beta > 0 ? "Beta-plane (expecting Western Intensification)" : "f-plane (expecting symmetry)"}
      Simulation status: ${params.isRunning ? "Running" : "Paused"}
    `;

    const answer = await askOceanographer(userMsg.text, context);
    
    setMessages(prev => [...prev, { role: 'model', text: answer }]);
    setIsLoading(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-800 border-l border-slate-700 shadow-xl w-80">
      <div className="p-4 border-b border-slate-700 bg-slate-800/50 backdrop-blur">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <span className="text-xl">🎓</span> AI Oceanographer
        </h3>
      </div>
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] rounded-lg p-3 text-sm leading-relaxed ${
              m.role === 'user' 
                ? 'bg-cyan-600 text-white' 
                : 'bg-slate-700 text-slate-200 border border-slate-600'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-slate-700 rounded-lg p-3 text-sm text-slate-400 animate-pulse">
               Thinking about fluid dynamics...
             </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-700 bg-slate-900">
        <div className="flex gap-2">
          <input 
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask a question..."
            className="flex-1 bg-slate-800 border border-slate-600 text-white rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading}
            className="bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white px-3 py-2 rounded-md transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};