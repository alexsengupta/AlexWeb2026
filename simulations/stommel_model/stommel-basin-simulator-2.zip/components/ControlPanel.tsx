
import React, { useState } from 'react';
import { SimulationParams, WindProfile } from '../types';

interface ControlPanelProps {
  params: SimulationParams;
  setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
  onReset: () => void;
}

const Tooltip: React.FC<{ text: string }> = ({ text }) => {
  const [show, setShow] = useState(false);
  return (
    <div className="relative inline-block ml-2">
      <div 
        className="w-4 h-4 rounded-full bg-slate-600 text-[10px] flex items-center justify-center text-slate-200 cursor-help hover:bg-cyan-600 transition-colors"
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
      >
        ?
      </div>
      {show && (
        <div className="absolute z-50 bottom-full mb-2 left-1/2 -translate-x-1/2 w-48 bg-slate-800 text-slate-200 text-xs p-2 rounded shadow-xl border border-slate-600 pointer-events-none">
          {text}
        </div>
      )}
    </div>
  );
};

export const ControlPanel: React.FC<ControlPanelProps> = ({ params, setParams, onReset }) => {

  const getSimulationDescription = (p: SimulationParams) => {
    const isf0Zero = Math.abs(p.f0) < 1e-10;
    const isBetaZero = Math.abs(p.beta) < 1e-13;
    
    const tau = p.windStress;
    const isDouble = p.windProfile === 'DOUBLE_GYRE';
    
    let parts = [];

    // 1. Geography / Rotation Analysis
    if (isf0Zero) {
        if (isBetaZero) {
            // Case: f = 0, beta = 0
            parts.push("Non-rotating system (Pure Friction). No Coriolis force.");
        } else {
            // Case: f = beta * y
            // If beta > 0, f goes 0 -> +beta*L (NH Equatorial)
            // If beta < 0, f goes 0 -> -beta*L (SH Equatorial - if y is distance from equator)
            // Note: In this model y=0 is south wall.
            if (p.beta > 0) parts.push("Northern Hemisphere Equatorial Basin (f=0 at South wall).");
            else parts.push("Southern Hemisphere Equatorial Basin (f=0 at South wall).");
        }
    } else {
        // Standard f-plane or Beta-plane
        if (p.f0 > 0) parts.push("Northern Hemisphere");
        else parts.push("Southern Hemisphere");

        if (isBetaZero) parts.push("(f-plane, constant rotation).");
        else if (p.beta > 0) parts.push("(Standard Earth rotation).");
        else parts.push("(Reverse Earth rotation/beta).");
    }

    // 2. Circulation Expectation
    let circulation = "";
    if (Math.abs(tau) < 0.01) {
        return "Ocean at rest (No wind forcing).";
    }

    if (isDouble) {
        circulation = "a Double Gyre system.";
    } else {
        if (p.f0 > 0 || (isf0Zero && p.beta > 0)) {
            if (tau > 0) circulation = "a Subtropical Gyre (Clockwise).";
            else circulation = "a Subpolar Gyre (Counter-clockwise).";
        } else {
            // SH or Reverse
            if (tau < 0) circulation = "a Subtropical Gyre (Counter-clockwise in SH).";
            else circulation = "a Subpolar Gyre.";
        }
    }

    // 3. Boundary Current
    let boundary = "";
    if (!isBetaZero) {
        if (p.beta > 0) boundary = " Expect Western Intensification (Stommel).";
        else boundary = " Expect Eastern Intensification (Reverse Beta).";
    } else {
        boundary = " Expect symmetric gyres (No intensification on f-plane).";
    }
    
    if (isf0Zero && isBetaZero) boundary = " Flow follows wind directly (no rotation).";

    return `This setup represents ${parts.join(" ")} simulating ${circulation}${boundary}`;
  };

  return (
    <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white mb-1">Physics Controls</h2>
        <p className="text-slate-400 text-xs">
          <b>Click on the ocean</b> to release drifting particles!
        </p>
      </div>

      <div className="space-y-4">
        
        {/* Wind Profile */}
        <div className="space-y-1">
           <div className="flex items-center">
               <label className="text-sm text-slate-300">Wind Profile</label>
               <Tooltip text="Pattern of wind forcing. Single gyre creates one large loop; Double gyre creates two opposing loops." />
           </div>
           <div className="grid grid-cols-2 gap-2">
             <button
               onClick={() => setParams(p => ({...p, windProfile: 'SINGLE_GYRE'}))}
               className={`py-1.5 px-2 text-xs rounded border ${params.windProfile === 'SINGLE_GYRE' ? 'bg-emerald-900/50 border-emerald-500 text-emerald-100' : 'border-slate-600 text-slate-400 hover:bg-slate-700'}`}
             >
               Single Gyre
             </button>
             <button
               onClick={() => setParams(p => ({...p, windProfile: 'DOUBLE_GYRE'}))}
               className={`py-1.5 px-2 text-xs rounded border ${params.windProfile === 'DOUBLE_GYRE' ? 'bg-emerald-900/50 border-emerald-500 text-emerald-100' : 'border-slate-600 text-slate-400 hover:bg-slate-700'}`}
             >
               Double Gyre
             </button>
           </div>
        </div>

        {/* Sliders */}
        <div className="space-y-1">
          <div className="flex justify-between text-sm text-slate-300 items-center">
            <div className="flex items-center">
                <label>Coriolis (f₀)</label>
                <Tooltip text="Planetary rotation rate. Positive for Northern Hemisphere, Negative for Southern/Reverse." />
            </div>
            <span>{params.f0.toExponential(1)}</span>
          </div>
          <input 
            type="range" 
            min="-1.5e-4" max="1.5e-4" step="0.1e-4" 
            value={params.f0}
            onChange={(e) => setParams(p => ({...p, f0: parseFloat(e.target.value)}))}
            className="w-full accent-cyan-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-sm text-slate-300 items-center">
            <div className="flex items-center">
                <label>Beta Effect (β)</label>
                <Tooltip text="Change in Coriolis with latitude. Positive for Earth. Negative for reverse rotation." />
            </div>
            <span>{params.beta.toExponential(1)}</span>
          </div>
          <input 
            type="range" 
            min="-5e-11" max="5e-11" step="0.2e-11" 
            value={params.beta}
            onChange={(e) => setParams(p => ({...p, beta: parseFloat(e.target.value)}))}
            className="w-full accent-indigo-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-sm text-slate-300 items-center">
            <div className="flex items-center">
                <label>Wind Stress (τ)</label>
                <Tooltip text="Strength and direction of the wind forcing. Negative values reverse the wind direction (e.g. for SH)." />
            </div>
            <span>{params.windStress.toFixed(2)} Pa</span>
          </div>
          <input 
            type="range" 
            min="-0.5" max="0.5" step="0.01" 
            value={params.windStress}
            onChange={(e) => setParams(p => ({...p, windStress: parseFloat(e.target.value)}))}
            className="w-full accent-emerald-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-sm text-slate-300 items-center">
            <div className="flex items-center">
                <label>Bottom Friction (r)</label>
                <Tooltip text="Linear drag at the ocean floor. Helps balance vorticity input from wind." />
            </div>
            <span>{params.drag.toExponential(1)}</span>
          </div>
          <input 
            type="range" 
            min="1e-7" max="5e-5" step="1e-7" 
            value={params.drag}
            onChange={(e) => setParams(p => ({...p, drag: parseFloat(e.target.value)}))}
            className="w-full accent-orange-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="space-y-1">
          <div className="flex justify-between text-sm text-slate-300 items-center">
            <div className="flex items-center">
                <label>Lateral Viscosity (Ah)</label>
                <Tooltip text="Horizontal fluid friction. Smooths out small scale noise and enables Munk boundary layers." />
            </div>
            <span>{params.viscosity.toLocaleString()} m²/s</span>
          </div>
          <input 
            type="range" 
            min="0" max="1000000" step="10000" 
            value={params.viscosity}
            onChange={(e) => setParams(p => ({...p, viscosity: parseFloat(e.target.value)}))}
            className="w-full accent-purple-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <hr className="border-slate-700" />
        
        <div className="space-y-2">
            <div className="flex items-center justify-between">
               <label className="text-sm text-slate-300 flex items-center gap-2 cursor-pointer">
                 <input 
                  type="checkbox" 
                  checked={params.showVectors}
                  onChange={(e) => setParams(p => ({...p, showVectors: e.target.checked}))}
                  className="w-4 h-4 rounded border-slate-600 text-cyan-500 focus:ring-cyan-500 bg-slate-700"
                 />
                 Show Velocity Vectors
               </label>
            </div>
        </div>

        <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-700 text-xs text-slate-300 italic leading-relaxed">
            {getSimulationDescription(params)}
        </div>

        <div className="flex gap-2 pt-2">
           <button 
             onClick={() => setParams(p => ({...p, isRunning: !p.isRunning}))}
             className={`flex-1 py-2 px-4 rounded-lg font-bold text-white transition-all shadow-lg active:scale-95 ${
               params.isRunning 
               ? 'bg-amber-600 hover:bg-amber-500 shadow-amber-900/20' 
               : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20'
             }`}
           >
             {params.isRunning ? 'Pause' : 'Start'}
           </button>
           <button 
             onClick={onReset}
             className="px-4 py-2 bg-red-900/50 hover:bg-red-800 text-red-100 border border-red-800 rounded-lg font-semibold transition-all shadow-lg active:scale-95"
           >
             Reset
           </button>
        </div>

      </div>
    </div>
  );
};
