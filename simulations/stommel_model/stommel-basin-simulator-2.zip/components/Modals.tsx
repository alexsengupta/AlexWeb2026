
import React from 'react';

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl max-h-[90vh] rounded-xl shadow-2xl flex flex-col">
                <div className="flex justify-between items-center p-4 border-b border-slate-700">
                    <h2 className="text-xl font-bold text-white">{title}</h2>
                    <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
                <div className="p-6 overflow-y-auto text-slate-300 leading-relaxed space-y-4">
                    {children}
                </div>
            </div>
        </div>
    );
};

export const HelpModal: React.FC<{ isOpen: boolean, onClose: () => void }> = (props) => (
    <Modal title="Simulation Guide" {...props}>
        <div className="space-y-4">
            <p>
                Welcome to the <b>Stommel Basin Simulator</b>. This interactive tool models ocean circulation in a simplified rectangular basin, driven by wind stress.
            </p>
            
            <h3 className="text-lg font-semibold text-white">How to Use</h3>
            <ul className="list-disc pl-5 space-y-1">
                <li><b>Visualize:</b> Watch the Sea Surface Height (SSH) evolve. High pressure (red) generally corresponds to clockwise flow in the NH.</li>
                <li><b>Particles:</b> Click anywhere on the map to release green drift particles to trace the currents.</li>
                <li><b>Controls:</b> Use the panel on the right to adjust physical parameters in real-time.</li>
                <li><b>Instability:</b> If the simulation turns <span className="text-red-400">red</span> and explodes, it means the numerical solver has become unstable. This usually happens if friction/viscosity is too low or wind is too strong. <b>Try increasing Viscosity or Friction, then click Reset.</b></li>
            </ul>

            <h3 className="text-lg font-semibold text-white">Things to Try</h3>
            <ul className="list-disc pl-5 space-y-1">
                <li><b>Western Intensification:</b> Set Beta positive (Standard Earth). Notice how currents crowd on the western boundary (left).</li>
                <li><b>f-Plane:</b> Set Beta to 0. Notice the gyre becomes symmetric.</li>
                <li><b>Southern Hemisphere:</b> Set f0 negative. The flow direction reverses (counter-clockwise for high pressure).</li>
                <li><b>Reverse Beta:</b> Set Beta negative. Watch the boundary current move to the East!</li>
            </ul>
        </div>
    </Modal>
);

export const InfoModal: React.FC<{ isOpen: boolean, onClose: () => void }> = (props) => (
    <Modal title="Model Physics" {...props}>
         <div className="space-y-4 text-sm">
            <p>
                The model solves the depth-averaged Shallow Water Equations on a C-grid using a simplified finite-difference scheme.
            </p>

            <div className="bg-slate-950 p-4 rounded border border-slate-800 font-mono text-xs overflow-x-auto">
                <p className="mb-2 text-slate-500">// Momentum Equations (Linear)</p>
                <p>∂u/∂t - fv = -g ∂η/∂x + τx/(ρH) - ru + Ah ∇²u</p>
                <p>∂v/∂t + fu = -g ∂η/∂y + τy/(ρH) - rv + Ah ∇²v</p>
                <br/>
                <p className="mb-2 text-slate-500">// Continuity Equation</p>
                <p>∂η/∂t + ∂(Hu)/∂x + ∂(Hv)/∂y = 0</p>
            </div>

            <h3 className="text-base font-semibold text-white mt-4">Key Terms</h3>
            <ul className="list-disc pl-5 space-y-2">
                <li><b>Coriolis (f):</b> Deflects moving fluid. $f = f_0 + \beta y$.</li>
                <li><b>Beta (β):</b> The variation of Coriolis with latitude. This term is crucial for the <b>Sverdrup Balance</b> and causes the Western Boundary Current (Stommel, 1948).</li>
                <li><b>Wind Stress (τ):</b> The engine of the circulation. Easterly trade winds in the south and Westerlies in the north create a torque (curl) on the ocean.</li>
                <li><b>Friction (r) & Viscosity (Ah):</b> Dissipate energy and allow a steady state to form. High viscosity leads to a Munk-layer solution.</li>
            </ul>
        </div>
    </Modal>
);
