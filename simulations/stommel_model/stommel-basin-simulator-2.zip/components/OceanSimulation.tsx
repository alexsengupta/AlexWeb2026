
import React, { useRef, useEffect, useCallback, useState } from 'react';
import { SimulationParams } from '../types';
import { BASIN_HEIGHT_KM, BASIN_WIDTH_KM, COLOR_MAP, DEPTH_M, DT, GRAVITY, PARTICLE_SPEED_SCALE } from '../constants';

interface OceanSimulationProps {
  params: SimulationParams;
}

interface Particle {
  x: number; // Grid coordinates (0 to N)
  y: number; // Grid coordinates (0 to N)
  life: number;
}

export const OceanSimulation: React.FC<OceanSimulationProps> = ({ params }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>(0);
  const [exploded, setExploded] = useState(false);
  const mouseRef = useRef<{x: number, y: number, isDown: boolean}>({ x: 0, y: 0, isDown: false });
  const timeRef = useRef<number>(0); // Simulation time in seconds
  
  // Simulation State stored in Refs to avoid react render cycle for physics loop
  const N = params.gridResolution;
  const state = useRef({
    u: new Float32Array((N + 1) * N),
    v: new Float32Array(N * (N + 1)),
    h: new Float32Array(N * N),
    h_new: new Float32Array(N * N),
    u_new: new Float32Array((N + 1) * N),
    v_new: new Float32Array(N * (N + 1)),
    particles: [] as Particle[],
    dx: (BASIN_WIDTH_KM * 1000) / N,
    dy: (BASIN_HEIGHT_KM * 1000) / N
  });

  const resetSimulation = useCallback(() => {
    // Handled by parent key
  }, [N]);

  // Layout Constants
  const MARGIN_TOP = 85; // Increased for Stats
  const MARGIN_BOTTOM = 50;
  const MARGIN_LEFT = 70;
  const MARGIN_RIGHT = 30;

  // Handle interaction for adding particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const getPos = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;
      return {
        x: clientX - rect.left,
        y: clientY - rect.top
      };
    };

    const handleDown = (e: MouseEvent | TouchEvent) => {
      mouseRef.current.isDown = true;
      const pos = getPos(e);
      mouseRef.current.x = pos.x;
      mouseRef.current.y = pos.y;
    };
    
    const handleUp = () => { mouseRef.current.isDown = false; };
    const handleMove = (e: MouseEvent | TouchEvent) => {
      if (!mouseRef.current.isDown) return;
      const pos = getPos(e);
      mouseRef.current.x = pos.x;
      mouseRef.current.y = pos.y;
    };

    canvas.addEventListener('mousedown', handleDown);
    canvas.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    canvas.addEventListener('touchstart', handleDown);
    canvas.addEventListener('touchmove', handleMove);
    window.addEventListener('touchend', handleUp);

    return () => {
      canvas.removeEventListener('mousedown', handleDown);
      canvas.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
      canvas.removeEventListener('touchstart', handleDown);
      canvas.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleUp);
    };
  }, []);

  const updatePhysics = () => {
    const { u, v, h, u_new, v_new, h_new, dx, dy, particles } = state.current;
    const { f0, beta, drag, windStress, viscosity, windProfile } = params;

    const H = DEPTH_M;
    const G = GRAVITY;
    const tau0 = windStress;
    const rho = 1025;
    const r = drag;
    const Ah = viscosity;

    let isUnstable = false;
    timeRef.current += DT;

    // 0. Inject Particles (Lagrangian) - Adjusted for Margins
    if (mouseRef.current.isDown && canvasRef.current) {
      const cvs = canvasRef.current;
      const drawW = cvs.width - MARGIN_LEFT - MARGIN_RIGHT;
      const drawH = cvs.height - MARGIN_TOP - MARGIN_BOTTOM;

      // Mouse relative to the simulation box
      const simMouseX = mouseRef.current.x - MARGIN_LEFT;
      const simMouseY = mouseRef.current.y - MARGIN_TOP;

      if (simMouseX >= 0 && simMouseX <= drawW && simMouseY >= 0 && simMouseY <= drawH) {
         const gridX = (simMouseX / drawW) * N;
         const gridY = (1 - simMouseY / drawH) * N;

         // Add a cluster of particles
         for (let k = 0; k < 5; k++) {
           particles.push({
             x: gridX + (Math.random() - 0.5) * 2,
             y: gridY + (Math.random() - 0.5) * 2,
             life: 0
           });
         }
      }
    }
    
    // Limit particle count
    if (particles.length > 3000) particles.splice(0, particles.length - 3000);

    // 1. Update u
    for (let j = 0; j < N; j++) {
      for (let i = 1; i < N; i++) {
        const idx = j * (N + 1) + i;
        const y = (j + 0.5) * dy;
        const f = f0 + beta * y;
        
        const v_avg = 0.25 * (
          v[j * N + i] + 
          v[j * N + (i - 1)] + 
          v[(j + 1) * N + i] + 
          v[(j + 1) * N + (i - 1)] 
        );

        const dEdx = (h[j * N + i] - h[j * N + (i - 1)]) / dx;

        let wind = 0;
        const L_y = N * dy;
        if (windProfile === 'SINGLE_GYRE') {
          wind = (-tau0 * Math.cos(Math.PI * y / L_y)) / (rho * H);
        } else {
          wind = (-tau0 * Math.cos(2 * Math.PI * y / L_y)) / (rho * H);
        }

        const bottomFric = -r * u[idx];
        
        let lapU = 0;
        if (Ah > 0) {
          const u_curr = u[idx];
          const u_E = (i + 1 < N) ? u[j * (N + 1) + (i + 1)] : 0; 
          const u_W = (i - 1 > 0) ? u[j * (N + 1) + (i - 1)] : 0; 
          const u_N = (j + 1 < N) ? u[(j + 1) * (N + 1) + i] : u_curr; // Free slip N/S
          const u_S = (j - 1 >= 0) ? u[(j - 1) * (N + 1) + i] : u_curr;
          lapU = Ah * ((u_E - 2 * u_curr + u_W) / (dx * dx) + (u_N - 2 * u_curr + u_S) / (dy * dy));
        }

        u_new[idx] = u[idx] + DT * (f * v_avg - G * dEdx + wind + bottomFric + lapU);
        
        if (isNaN(u_new[idx]) || Math.abs(u_new[idx]) > 500) isUnstable = true;
      }
    }

    // 2. Update v
    for (let j = 1; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const idx = j * N + i;
        const y = j * dy;
        const f = f0 + beta * y;

        const u_avg = 0.25 * (
          u[j * (N + 1) + i] + 
          u[j * (N + 1) + (i + 1)] + 
          u[(j - 1) * (N + 1) + i] + 
          u[(j - 1) * (N + 1) + (i + 1)]
        );

        const dEdy = (h[j * N + i] - h[(j - 1) * N + i]) / dy;
        const bottomFric = -r * v[idx];
        
        let lapV = 0;
        if (Ah > 0) {
          const v_curr = v[idx];
          const v_E = (i + 1 < N) ? v[j * N + (i + 1)] : v_curr; // Free slip E/W
          const v_W = (i - 1 >= 0) ? v[j * N + (i - 1)] : v_curr;
          const v_N = (j + 1 < N) ? v[(j + 1) * N + i] : 0;
          const v_S = (j - 1 > 0) ? v[(j - 1) * N + i] : 0;
          lapV = Ah * ((v_E - 2 * v_curr + v_W) / (dx * dx) + (v_N - 2 * v_curr + v_S) / (dy * dy));
        }

        v_new[idx] = v[idx] + DT * (-f * u_avg - G * dEdy + bottomFric + lapV);
        if (isNaN(v_new[idx]) || Math.abs(v_new[idx]) > 500) isUnstable = true;
      }
    }

    // 3. Update h
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const idx = j * N + i;
        const du_dx = (u_new[j * (N + 1) + (i + 1)] - u_new[j * (N + 1) + i]) / dx;
        const dv_dy = (v_new[(j + 1) * N + i] - v_new[j * N + i]) / dy;
        h_new[idx] = h[idx] - DT * H * (du_dx + dv_dy);
        if (isNaN(h_new[idx])) isUnstable = true;
      }
    }

    // 4. Advect Particles
    for (let p of particles) {
      const px = p.x;
      const py = p.y;
      
      // Interpolate u
      const uy_idx = py - 0.5;
      const ix = Math.floor(px);
      const iy = Math.floor(uy_idx);
      
      const wx = px - ix;
      const wy = uy_idx - iy;
      
      const i0 = Math.max(0, Math.min(N, ix));
      const i1 = Math.max(0, Math.min(N, ix + 1));
      const j0 = Math.max(0, Math.min(N - 1, iy));
      const j1 = Math.max(0, Math.min(N - 1, iy + 1));
      
      const u00 = u_new[j0 * (N + 1) + i0];
      const u10 = u_new[j0 * (N + 1) + i1];
      const u01 = u_new[j1 * (N + 1) + i0];
      const u11 = u_new[j1 * (N + 1) + i1];
      
      const u_val = (1 - wy) * ((1 - wx) * u00 + wx * u10) + wy * ((1 - wx) * u01 + wx * u11);

      // Interpolate v
      const vx_idx = px - 0.5;
      const jv = Math.floor(py);
      const iv = Math.floor(vx_idx);
      
      const wxv = vx_idx - iv;
      const wyv = py - jv;
      
      const iv0 = Math.max(0, Math.min(N - 1, iv));
      const iv1 = Math.max(0, Math.min(N - 1, iv + 1));
      const jv0 = Math.max(0, Math.min(N, jv));
      const jv1 = Math.max(0, Math.min(N, jv + 1));
      
      const v00 = v_new[jv0 * N + iv0];
      const v10 = v_new[jv0 * N + iv1];
      const v01 = v_new[jv1 * N + iv0];
      const v11 = v_new[jv1 * N + iv1];
      
      const v_val = (1 - wyv) * ((1 - wxv) * v00 + wxv * v10) + wyv * ((1 - wxv) * v01 + wxv * v11);
      
      p.x += (u_val * DT * PARTICLE_SPEED_SCALE) / dx;
      p.y += (v_val * DT * PARTICLE_SPEED_SCALE) / dy;
      p.life += DT;

      if (p.x < 0) { p.x = -p.x; }
      if (p.x >= N) { p.x = 2 * N - p.x - 0.01; }
      if (p.y < 0) { p.y = -p.y; }
      if (p.y >= N) { p.y = 2 * N - p.y - 0.01; }
    }


    if (isUnstable) return false;

    state.current.u.set(u_new);
    state.current.v.set(v_new);
    state.current.h.set(h_new);
    return true;
  };

  const draw = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const { h, u, v, particles } = state.current;
    
    // 1. Clear Full Canvas
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, width, height);

    if (exploded) {
      ctx.fillStyle = 'rgba(255, 100, 100, 0.2)';
      ctx.fillRect(0, 0, width, height);
      ctx.fillStyle = '#f87171';
      ctx.font = '24px Inter';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText("Simulation Unstable!", width/2, height/2);
      ctx.font = '14px Inter';
      ctx.fillText("Try increasing viscosity or friction, then Reset.", width/2, height/2 + 30);
      return;
    }

    // 2. Define Simulation Area (Inset)
    const drawW = width - MARGIN_LEFT - MARGIN_RIGHT;
    const drawH = height - MARGIN_TOP - MARGIN_BOTTOM;

    // We will translate to (MARGIN_LEFT, MARGIN_TOP) for all simulation drawing
    ctx.save();
    ctx.translate(MARGIN_LEFT, MARGIN_TOP);
    
    // Create clipping path to contain arrows and data
    ctx.beginPath();
    ctx.rect(0, 0, drawW, drawH);
    ctx.clip();

    // Draw Simulation Content (Grid)
    const cellW = drawW / N;
    const cellH = drawH / N;
    const maxAmp = 0.8; 
    
    // Statistics Trackers
    let minH = Infinity;
    let maxH = -Infinity;
    let maxSpeed = 0;

    // Draw SSH & Compute Stats
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const val = h[j * N + i];
        
        // Stats
        if (val < minH) minH = val;
        if (val > maxH) maxH = val;
        
        // Approximate speed at cell center
        const u_c = 0.5 * (u[j * (N + 1) + i] + u[j * (N + 1) + i + 1]);
        const v_c = 0.5 * (v[j * N + i] + v[(j + 1) * N + i]);
        const spd = Math.sqrt(u_c*u_c + v_c*v_c);
        if (spd > maxSpeed) maxSpeed = spd;

        // Render
        let norm = val / maxAmp;
        norm = Math.max(-1, Math.min(1, norm));
        
        const colorIdx = (norm + 1) / 2 * (COLOR_MAP.length - 1);
        const idxLow = Math.floor(colorIdx);
        const t = colorIdx - idxLow;
        const c1 = COLOR_MAP[idxLow];
        const c2 = COLOR_MAP[Math.ceil(colorIdx)];

        const r = Math.round(c1[0] + (c2[0] - c1[0]) * t);
        const g = Math.round(c1[1] + (c2[1] - c1[1]) * t);
        const b = Math.round(c1[2] + (c2[2] - c1[2]) * t);

        ctx.fillStyle = `rgb(${r},${g},${b})`;
        ctx.fillRect(i * cellW, (N - 1 - j) * cellH, cellW + 1, cellH + 1); 
      }
    }

    // Draw Wind Vectors Overlay (Inset)
    ctx.globalAlpha = 1.0;
    ctx.strokeStyle = 'rgba(100, 149, 237, 0.4)';
    ctx.fillStyle = 'rgba(100, 149, 237, 0.4)';
    ctx.lineWidth = 4;
    
    const wxCount = 5;
    const wyCount = 5;
    
    // Inset logic: 10% padding on sides
    const padX = 0.1 * drawW;
    const padY = 0.1 * drawH;
    const usableW = drawW - 2 * padX;
    const usableH = drawH - 2 * padY;

    for (let j = 0; j <= wyCount; j++) {
       const yFrac = j / wyCount;
       // yNorm for physics (0 is south, 1 is north). 
       // Canvas y is inverse (0 is top/North).
       // We map j to physical Y coord relative to basin for wind calc.
       // Here we want arrows distributed visually evenly in the padded box.
       
       const cy = padY + yFrac * usableH; // Canvas Y position
       const yPhysicalNorm = 1 - (cy / drawH); // 0 at bottom, 1 at top roughly (if pad was 0)
       
       let windFactor = 0;
       // Correct wind profile sampling based on physical location
       if (params.windProfile === 'SINGLE_GYRE') {
          windFactor = -Math.cos(Math.PI * yPhysicalNorm); 
       } else {
          windFactor = -Math.cos(2 * Math.PI * yPhysicalNorm);
       }
       
       for(let i = 0; i <= wxCount; i++) {
         const xFrac = i / wxCount;
         const cx = padX + xFrac * usableW;
         
         const baseLen = 400 * Math.abs(params.windStress); 
         const arrowLen = baseLen * windFactor * Math.sign(params.windStress);
         
         // Only draw if inside or near frame
         ctx.beginPath();
         ctx.moveTo(cx, cy);
         ctx.lineTo(cx + arrowLen, cy);
         ctx.stroke();
         
         if (Math.abs(arrowLen) > 5) {
             const dir = Math.sign(arrowLen);
             const headSize = 12;
             ctx.beginPath();
             ctx.moveTo(cx + arrowLen, cy);
             ctx.lineTo(cx + arrowLen - dir * headSize, cy - headSize * 0.5);
             ctx.lineTo(cx + arrowLen - dir * headSize, cy + headSize * 0.5);
             ctx.fill();
         }
       }
    }

    // Draw Particles
    ctx.fillStyle = '#a3e635'; // Lime Green
    ctx.globalAlpha = 1.0;
    for (const p of particles) {
      const cx = p.x * cellW;
      const cy = (N - p.y) * cellH;
      ctx.beginPath();
      ctx.arc(cx, cy, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw Velocity Vectors
    if (params.showVectors) {
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.lineWidth = 1.5; 
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      
      const step = Math.ceil(N / 20); 

      for (let j = 1; j < N - 1; j += step) {
        for (let i = 1; i < N - 1; i += step) {
          const u_val = 0.5 * (u[j*(N+1)+i] + u[j*(N+1)+i+1]);
          const v_val = 0.5 * (v[j*N+i] + v[(j+1)*N+i]);
          const magnitude = Math.sqrt(u_val*u_val + v_val*v_val);
          if (magnitude < 0.005) continue; 

          const cx = (i + 0.5) * cellW;
          const cy = (N - 1 - j - 0.5) * cellH; 

          const vectorScale = 60 * cellW; 
          const vx = u_val * vectorScale;
          const vy = -v_val * vectorScale; 

          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(cx + vx, cy + vy);
          ctx.stroke();
          
          const headLen = 4; 
          const angle = Math.atan2(vy, vx);
          
          ctx.beginPath();
          ctx.moveTo(cx + vx, cy + vy);
          ctx.lineTo(cx + vx - headLen * Math.cos(angle - Math.PI / 6), cy + vy - headLen * Math.sin(angle - Math.PI / 6));
          ctx.lineTo(cx + vx - headLen * Math.cos(angle + Math.PI / 6), cy + vy - headLen * Math.sin(angle + Math.PI / 6));
          ctx.lineTo(cx + vx, cy + vy);
          ctx.fill();
        }
      }
    }
    
    // Remove Clip
    ctx.restore(); 

    // Draw Border around Simulation Area
    ctx.save();
    ctx.translate(MARGIN_LEFT, MARGIN_TOP);
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, drawW, drawH);
    ctx.restore();
    
    // --- Draw UI Elements in Margins ---

    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px Inter';
    
    // 3. X-Axis Labels (Bottom Margin)
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const xAxisY = height - MARGIN_BOTTOM + 10;
    
    ctx.fillText('0 km', MARGIN_LEFT, xAxisY);
    ctx.fillText(`${BASIN_WIDTH_KM / 2} km`, MARGIN_LEFT + drawW / 2, xAxisY);
    ctx.fillText(`${BASIN_WIDTH_KM} km`, MARGIN_LEFT + drawW, xAxisY);
    
    // 4. Y-Axis Labels (Left Margin)
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    const yAxisX = MARGIN_LEFT - 10;
    
    ctx.fillText('0 km', yAxisX, height - MARGIN_BOTTOM);
    ctx.fillText(`${BASIN_HEIGHT_KM / 2} km`, yAxisX, height - MARGIN_BOTTOM - drawH / 2);
    ctx.fillText(`${BASIN_HEIGHT_KM} km`, yAxisX, MARGIN_TOP);
    
    // 5. Time Display (Top Center Margin)
    const days = Math.floor(timeRef.current / (24 * 3600));
    const years = (timeRef.current / (365 * 24 * 3600)).toFixed(1);
    
    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 24px Inter'; 
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText(`Time: ${days} days (${years} yrs)`, width / 2, MARGIN_TOP - 20);

    // 6. Wind Legend & Stats (Top Left Margin)
    const legendX = MARGIN_LEFT;
    const legendY = MARGIN_TOP - 55; // Higher up in the expanded margin
    
    ctx.font = '14px Inter';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#fbbf24';
    
    // Wind Arrow Legend
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(100, 149, 237, 1)';
    ctx.lineWidth = 3;
    ctx.moveTo(legendX, legendY);
    ctx.lineTo(legendX + 30, legendY);
    ctx.stroke();
    // Arrow Head
    ctx.beginPath();
    ctx.fillStyle = 'rgba(100, 149, 237, 1)';
    ctx.moveTo(legendX + 30, legendY);
    ctx.lineTo(legendX + 24, legendY - 4);
    ctx.lineTo(legendX + 24, legendY + 4);
    ctx.fill();
    
    ctx.fillText('Wind Stress', legendX + 40, legendY);

    // Stats
    ctx.font = '12px Inter';
    ctx.fillStyle = '#cbd5e1'; // lighter slate
    ctx.fillText(`Max Flow Speed: ${maxSpeed.toFixed(2)} m/s`, legendX, legendY + 20);
    ctx.fillText(`SSH Range: [${minH.toFixed(2)}m, ${maxH.toFixed(2)}m]`, legendX, legendY + 38);

  };

  const loop = useCallback(() => {
    if (params.isRunning && !exploded) {
      for(let k=0; k<4; k++) {
        if (!updatePhysics()) {
          setExploded(true);
          break;
        }
      }
    }

    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        draw(ctx, canvas.width, canvas.height);
      }
    }
    
    if (!exploded) {
      animationRef.current = requestAnimationFrame(loop);
    }
  }, [params, N, exploded]); 

  useEffect(() => {
    animationRef.current = requestAnimationFrame(loop);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [loop]);

  useEffect(() => {
     if (!containerRef.current || !canvasRef.current) return;
     
     const observer = new ResizeObserver(entries => {
       for (const entry of entries) {
         if (canvasRef.current) {
            canvasRef.current.width = entry.contentRect.width;
            canvasRef.current.height = entry.contentRect.height;
         }
       }
     });
     observer.observe(containerRef.current);
     return () => observer.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="w-full h-full flex items-center justify-center bg-slate-900 rounded-xl overflow-hidden shadow-inner border border-slate-800 cursor-crosshair relative">
      <canvas ref={canvasRef} className="block w-full h-full" />
    </div>
  );
};
