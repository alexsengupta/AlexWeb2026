
export const BASIN_WIDTH_KM = 12000; // Pacific Scale
export const BASIN_HEIGHT_KM = 8000;
export const DEPTH_M = 1000; // Upper ocean layer depth
export const GRAVITY = 9.81; // Reduced gravity could be used here (e.g. 0.02) for 1.5 layer, but we'll stick to full G for barotropic mode
export const DT = 400; // Reduced to 400s to ensure stability with the current grid and parameters.
export const PARTICLE_SPEED_SCALE = 250; // Artificial multiplier to make advection visible on map

// Colormap colors for SSH (Sea Surface Height)
// Blue (low) -> White (neutral) -> Red (high)
export const COLOR_MAP = [
  [10, 25, 70],    // Deep Blue
  [20, 60, 140],   // Medium Blue
  [60, 130, 190],  // Light Blue
  [240, 240, 245], // White/Neutral
  [220, 140, 100], // Light Orange
  [190, 60, 40],   // Medium Red
  [100, 20, 20]    // Deep Red
];
