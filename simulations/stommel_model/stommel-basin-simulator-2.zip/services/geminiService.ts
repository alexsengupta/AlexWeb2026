import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const askOceanographer = async (question: string, context: string): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please check your environment configuration.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `
You are an expert physical oceanographer and teacher. 
A student is running a numerical simulation of a rectangular ocean basin.
They are asking: "${question}"

Current Simulation Context:
${context}

Explain the physics concepts clearly and concisely (under 150 words). 
Focus on concepts like geostrophy, Ekman transport, Sverdrup balance, vorticity, and western boundary intensification if relevant.
Avoid overly complex mathematical jargon unless necessary, but be precise.
`,
    });
    return response.text || "I couldn't generate an explanation at this moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I'm having trouble connecting to the oceanographic database right now.";
  }
};