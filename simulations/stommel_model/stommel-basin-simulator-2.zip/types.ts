
export type WindProfile = 'SINGLE_GYRE' | 'DOUBLE_GYRE';

export interface SimulationParams {
  beta: number; // Beta plane parameter (gradient of f)
  f0: number; // Base Coriolis parameter
  drag: number; // Bottom friction
  windStress: number; // Amplitude of wind stress
  viscosity: number; // Lateral viscosity
  windProfile: WindProfile; // Pattern of the wind
  isRunning: boolean;
  showVectors: boolean;
  gridResolution: number; // Size of the grid (N x N)
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export enum SimulationPreset {
  // Deprecated but kept if needed for reference, though unused in UI now
  REST = 'REST',
}
